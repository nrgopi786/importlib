CPE2_3_WFN class
================

.. autoclass:: cpe.cpe2_3_wfn.CPE2_3_WFN
   :members:
   :special-members:
