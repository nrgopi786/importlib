CPE2_3_URI class
================

.. autoclass:: cpe.cpe2_3_uri.CPE2_3_URI
   :members:
   :special-members:
