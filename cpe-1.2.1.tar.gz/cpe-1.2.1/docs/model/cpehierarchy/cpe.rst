CPE class
=========

.. autoclass:: cpe.cpe.CPE
   :members:
   :special-members:
