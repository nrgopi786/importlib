CPE2_3 class
============

.. autoclass:: cpe.cpe2_3.CPE2_3
   :members:
   :special-members:
