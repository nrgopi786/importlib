CPE2_3_FS class
===============

.. autoclass:: cpe.cpe2_3_fs.CPE2_3_FS
   :members:
   :special-members:
