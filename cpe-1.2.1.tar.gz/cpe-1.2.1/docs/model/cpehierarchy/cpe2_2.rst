CPE2_2 class
============

.. autoclass:: cpe.cpe2_2.CPE2_2
   :members:
   :special-members:
