CPEComponentEmpty class
=======================

.. autoclass:: cpe.comp.cpecomp_empty.CPEComponentEmpty
   :members:
   :special-members:
