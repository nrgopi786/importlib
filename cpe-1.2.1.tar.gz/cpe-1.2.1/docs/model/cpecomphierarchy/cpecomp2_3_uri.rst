CPEComponent2_3_URI class
=========================

.. autoclass:: cpe.comp.cpecomp2_3_uri.CPEComponent2_3_URI
   :members:
   :special-members:
