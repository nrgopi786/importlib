CPEComponent2_2 class
=====================

.. autoclass:: cpe.comp.cpecomp2_2.CPEComponent2_2
   :members:
   :special-members:
