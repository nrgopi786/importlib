CPEComponent class
==================

.. autoclass:: cpe.comp.cpecomp.CPEComponent
   :members:
   :special-members:
