CPEComponent2_3 class
=====================

.. autoclass:: cpe.comp.cpecomp2_3.CPEComponent2_3
   :members:
   :special-members:
