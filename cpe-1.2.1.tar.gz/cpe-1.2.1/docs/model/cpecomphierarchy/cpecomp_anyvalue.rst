CPEComponentAnyValue class
==========================

.. autoclass:: cpe.comp.cpecomp_anyvalue.CPEComponentAnyValue
   :members:
   :special-members:
