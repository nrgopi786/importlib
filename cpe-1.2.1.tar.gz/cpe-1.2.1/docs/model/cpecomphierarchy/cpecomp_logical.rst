CPEComponentLogical class
=========================

.. autoclass:: cpe.comp.cpecomp_logical.CPEComponentLogical
   :members:
   :special-members:
