CPEComponentNotApplicable class
===============================

.. autoclass:: cpe.comp.cpecomp_notapplicable.CPEComponentNotApplicable
   :members:
   :special-members:
