CPEComponent2_3_WFN class
=========================

.. autoclass:: cpe.comp.cpecomp2_3_wfn.CPEComponent2_3_WFN
   :members:
   :special-members:
