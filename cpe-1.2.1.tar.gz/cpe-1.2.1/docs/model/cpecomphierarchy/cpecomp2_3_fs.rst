CPEComponent2_3_FS class
========================

.. autoclass:: cpe.comp.cpecomp2_3_fs.CPEComponent2_3_FS
   :members:
   :special-members:
