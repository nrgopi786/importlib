CPEComponent1_1 class
=====================

.. autoclass:: cpe.comp.cpecomp1_1.CPEComponent1_1
   :members:
   :special-members:
