CPEComponent2_3_edpacked class
==============================

.. autoclass:: cpe.comp.cpecomp2_3_uri_edpacked.CPEComponent2_3_URI_edpacked
   :members:
   :special-members:
