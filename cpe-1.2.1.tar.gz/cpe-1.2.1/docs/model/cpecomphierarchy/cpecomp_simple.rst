CPEComponentSimple class
========================

.. autoclass:: cpe.comp.cpecomp_simple.CPEComponentSimple
   :members:
   :special-members:
