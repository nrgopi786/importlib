CPELanguage2_3 class
====================

.. autoclass:: cpe.cpelang2_3.CPELanguage2_3
   :members:
   :special-members:
