CPELanguage class
=================

.. autoclass:: cpe.cpelang.CPELanguage
   :members:
   :special-members:
