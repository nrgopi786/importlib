CPELanguage2_2 class
====================

.. autoclass:: cpe.cpelang2_2.CPELanguage2_2
   :members:
   :special-members:
