CPESet1_1 class
===============

.. autoclass:: cpe.cpeset1_1.CPESet1_1
   :members:
   :special-members:
