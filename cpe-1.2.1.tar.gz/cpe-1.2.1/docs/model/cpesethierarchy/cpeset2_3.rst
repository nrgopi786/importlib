CPESet2_3 class
===============

.. autoclass:: cpe.cpeset2_3.CPESet2_3
   :members:
   :special-members:
