CPESet class
============

.. autoclass:: cpe.cpeset.CPESet
   :members:
   :special-members:
