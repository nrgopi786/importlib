CPESet2_2 class
===============

.. autoclass:: cpe.cpeset2_2.CPESet2_2
   :members:
   :special-members:
