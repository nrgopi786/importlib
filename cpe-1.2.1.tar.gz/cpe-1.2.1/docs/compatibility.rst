Compatibility among CPE versions
================================

========  =====================  =========================  =========================  =========================  =========================
VERSIONS  1.1                    2.2                        2.3 WFN                    2.3 URI                    2.3 FS 
========  =====================  =========================  =========================  =========================  =========================
1.1       Yes                    Depends of count of parts  Depends of count of parts  Depends of count of parts  Depends of count of parts
2.2       Depends of characters  Yes                        Yes                        Yes                        Yes
2.3 WFN   Depends of characters  Depends of characters      Yes                        Yes                        Yes
2.3 URI   Depends of characters  Depends of characters      Yes                        Yes                        Yes
2.3 FS    Depends of characters  Depends of characters      Yes                        Yes                        Yes
========  =====================  =========================  =========================  =========================  =========================
