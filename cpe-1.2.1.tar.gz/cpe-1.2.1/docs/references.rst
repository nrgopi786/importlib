References
==========

* [1] CPE: `<http://scap.nist.gov/specifications/cpe/>`_
* [2] About CPE: `<http://cpe.mitre.org/about/>`_
* [3] CPE Archive: `<http://cpe.mitre.org/cpe/archive/>`_
* [4] CPE 1.1: `<http://cpe.mitre.org/specification/1.1/cpe-specification_1.1.pdf>`_
* [5] CPE 2.2: `<http://cpe.mitre.org/specification/2.2/cpe-specification_2.2.pdf>`_
* [6] CPE 2.3 - Naming Specification: `<http://csrc.nist.gov/publications/nistir/ir7695/NISTIR-7695-CPE-Naming.pdf>`_
* [7] CPE 2.3 - Name Matching Specification: `<http://csrc.nist.gov/publications/nistir/ir7696/NISTIR-7696-CPE-Matching.pdf>`_
* [8] CPE 2.3 - Applicability Language Specification: `<http://csrc.nist.gov/publications/nistir/ir7698/NISTIR-7698-CPE-Language.pdf>`_
