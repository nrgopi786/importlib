Installation
============

Install the package using pip::

    pip install cpe

or execute the setup.py file in package::

    python setup.py install

