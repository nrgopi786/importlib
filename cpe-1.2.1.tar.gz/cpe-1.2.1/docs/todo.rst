TODO
====

* Implement methods *ovalcheck* and *ocilcheck* of :class:`CPELanguage2_3` class.
* Implement versions 2.0 and 2.1 of CPE specification.
* Implement methods *as\_uri\_1\_1* and *as\_uri\_2\_2* to convert any CPE Name into a CPE Name of versions 1.1 and 2.2 respectively.
